# BluetoothDevice Object

* `deviceName` string
* `deviceId` string
