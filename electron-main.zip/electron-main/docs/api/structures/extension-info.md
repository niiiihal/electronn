# ExtensionInfo Object

* `name` string
* `version` string
