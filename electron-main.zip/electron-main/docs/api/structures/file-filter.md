# FileFilter Object

* `name` string
* `extensions` string[]
