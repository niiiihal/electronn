# MimeTypedBuffer Object

* `mimeType` string (optional) - MIME type of the buffer.
* `charset` string (optional) - Charset of the buffer.
* `data` Buffer - The actual Buffer content.
