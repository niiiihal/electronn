# NavigationEntry Object

* `url` string
* `title` string
