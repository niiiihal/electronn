# ProtocolResponseUploadData Object

* `contentType` string - MIME type of the content.
* `data` string | Buffer - Content to be sent.
