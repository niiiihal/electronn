# SharingItem Object

* `texts` string[] (optional) - An array of text to share.
* `filePaths` string[] (optional) - An array of files to share.
* `urls` string[] (optional) - An array of URLs to share.
