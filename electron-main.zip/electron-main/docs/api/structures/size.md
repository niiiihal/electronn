# Size Object

* `width` number
* `height` number
