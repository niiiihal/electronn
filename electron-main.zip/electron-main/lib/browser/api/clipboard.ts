const clipboard = process._linkedBinding('electron_common_clipboard');

export default clipboard;
