export default process._linkedBinding('electron_browser_content_tracing');
