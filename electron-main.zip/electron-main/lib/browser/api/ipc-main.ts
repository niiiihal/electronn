import { IpcMainImpl } from '@electron/internal/browser/ipc-main-impl';

const ipcMain = new IpcMainImpl();

export default ipcMain;
