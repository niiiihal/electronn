const { nativeTheme } = process._linkedBinding('electron_browser_native_theme');

module.exports = nativeTheme;
