const safeStorage = process._linkedBinding('electron_browser_safe_storage');

module.exports = safeStorage;
