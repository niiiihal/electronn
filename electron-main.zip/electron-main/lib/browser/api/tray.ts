const { Tray } = process._linkedBinding('electron_browser_tray');

export default Tray;
